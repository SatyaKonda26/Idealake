
import DetailBanner from './detail-banner/DetailBanner'
import ServiceInfo from './detail/ServiceInfo'

export default function ServiceDetail() {
  return (
    <>
    <DetailBanner/>
    <ServiceInfo/>
    </>
  );
}
